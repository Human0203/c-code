﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using NPOI;
using NPOI.SS.UserModel;
using NPOI.HSSF.Util;
using NPOI.SS.Util;
using NPOI.HSSF.UserModel;
using NPOI.HPSF;
using NPOI.POIFS.FileSystem;
using NPOI.Util;
using NPOI.XSSF;
using NPOI.XSSF.UserModel;

namespace the_log_of_work
{
    public partial class Form1 : Form
    {
        public DateTime time_start;
        public string time_end = string.Empty;
        public string time_now = string.Empty;
        public TimeSpan time_diff ;
        public double time_total=0.0;

        public Form1()
        {
            InitializeComponent();
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            //timer2.Start();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button_iufaannq.Text.Equals("开始"))
            {
                if (!textBox_gszonwrs.Text.Equals(string.Empty))
                {
                    button_iufaannq.Text = "结束";
                    time_start = DateTime.Now;
                    label_kduiuijm.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    textBox_gszonwrs.Enabled = false;
                    timer1.Start();
                }
                else
                {
                    MessageBox.Show("至少输入一个工作内容行吗？！");
                }
                
            }
            else
            {
                if (textBox_gszonwrs.Text.Equals(string.Empty) ||
                comboBox_kehuue.Text.Equals(string.Empty) ||
                comboBox_xits.Text.Equals(string.Empty) ||
                comboBox_zoyenwxkda.Text.Equals(string.Empty) ||
                comboBox_zoyenwxkxn.Text.Equals(string.Empty))
                {
                    MessageBox.Show("输入数据没有填写完，能不能检查一下呢！");
                }
                else
                {

                    button_iufaannq.Text = "开始";
                    time_end = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    textBox_gszonwrs.Enabled = true;
                    this.record();
                    textBox_gszonwrs.Text=string.Empty;
                    comboBox_kehuue.Text=string.Empty;
                    comboBox_xits.Text=string.Empty;
                    comboBox_zoyenwxkda.Text=string.Empty;
                    comboBox_zoyenwxkxn.Text=string.Empty;//数据清空
                    string result = string.Empty;
                    if (textBox1.Text.Equals(string.Empty))
                    {
                        time_total+=int.Parse(time_diff.Hours.ToString())+(double)int.Parse(time_diff.Minutes.ToString())/60;                        
                    }
                    else
                    {
                        double a= double.Parse(textBox1.Text);
                        time_total += int.Parse(time_diff.Hours.ToString()) + ((double)int.Parse(time_diff.Minutes.ToString()))/ 60+a;
                        
                    }
                    string st1="12:00";
                    DateTime dt1=Convert.ToDateTime(st1);
                    string st2 = "13:00";
                    DateTime dt2 = Convert.ToDateTime(st2);
                    if (DateTime.Compare(time_start, dt1) < 0 && DateTime.Compare(DateTime.Now, dt2) > 0)
                    {
                        time_total -= 1;
                    }
                    label_dhtmgszouijm.Text = time_total.ToString("N2") + " h";
                    textBox1.Text = string.Empty;
                    timer1.Stop();
                    textBox1.Enabled = false;

                }
            }
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            time_diff = DateTime.Now - time_start;
            label_iixuuijm.Text = time_diff.Hours.ToString() + ":" + time_diff.Minutes.ToString() + ":" + time_diff.Seconds.ToString();
        }

        private void record()
        {
            string tempPath =Application.StartupPath+ @"\工作日志\" + @"test.xlsx";
            XSSFWorkbook wk = null;
            using (FileStream fs = File.Open(tempPath, FileMode.Open,
FileAccess.Read, FileShare.ReadWrite))
            {
                //把xls文件读入workbook变量里，之后就可以关闭了
                wk = new XSSFWorkbook(fs);
                fs.Close();
            }
            
            ISheet sheet = wk.GetSheetAt(0);
            int rowcount = sheet.LastRowNum;
            IRow row = sheet.CreateRow(rowcount+1);
            row.CreateCell(0).SetCellValue(textBox3.Text);
            row.CreateCell(1).SetCellValue(textBox2.Text);
            row.CreateCell(2).SetCellValue("电子事业team LGE生产支援2part");
            row.CreateCell(3).SetCellValue(comboBox_zoyenwxkda.Text);
            row.CreateCell(4).SetCellValue(comboBox_zoyenwxkxn.Text);
            row.CreateCell(5).SetCellValue(comboBox_xits.Text);
            row.CreateCell(6).SetCellValue(textBox_gszonwrs.Text);
            row.CreateCell(7).SetCellValue(comboBox_kehuue.Text);
            row.CreateCell(8).SetCellValue(label_kduiuijm.Text);
            row.CreateCell(9).SetCellValue(time_end);
            row.CreateCell(10).CellFormula = "IF(AND(HOUR(J"+ (rowcount + 2)+ ")>=13,HOUR(I" + (rowcount + 2) + ")<=12),HOUR(J" + (rowcount + 2) + ")-HOUR(I" + (rowcount + 2) + ")+(MINUTE(J" + (rowcount + 2) + ")-MINUTE(I" + (rowcount + 2) + "))/60-1,HOUR(J" + (rowcount + 2) + ")-HOUR(I" + (rowcount + 2) + ")+(MINUTE(J" + (rowcount + 2) + ")-MINUTE(I" + (rowcount + 2) + "))/60)";
            //double time = 0.0;
            //for (int i = 1; i < sheet.LastRowNum-2 ; i++)
            //{
            //    IRow row_temp = sheet.GetRow(i);
            //    DateTime time_temp = row_temp.GetCell(9).DateCellValue;

            //    if (time_temp.ToString("MMdd").Equals(DateTime.Now.ToString("MMdd")))
            //    {
            //        MessageBox.Show(row_temp.GetCell(10).ToString());
            //        time += double.Parse(row_temp.GetCell(10).ToString());
            //    }
            //}
            
            using (FileStream fileStream = File.Open(tempPath, FileMode.Create, FileAccess.ReadWrite))
            {
                wk.Write(fileStream);
                fileStream.Close();
            }

            //return time;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            textBox1.Enabled =true;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            if (textBox_gszonwrs.Enabled ==true)
            {
                textBox_gszonwrs.Enabled = false;
            }
            else
            {
                textBox_gszonwrs.Enabled = true;
            }
            
        }

        private void label4_Click(object sender, EventArgs e)
        {
            textBox2.Enabled = true;
            textBox3.Enabled = true;
        }

        private void textBox_gszonwrs_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)//判断回车键
            {
                this.button1_Click(sender, e);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (button_iufaannq.Text.Equals("开始"))
            {
                if (textBox_gszonwrs.Text.Equals(string.Empty))
                {
                    textBox_gszonwrs.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                    dataGridView1.Rows.RemoveAt(e.RowIndex);
                    this.DataGridView1_CellEndEdit(sender, e);
                    this.button1_Click(sender, e);
                }
                else
                {
                    MessageBox.Show("已经有工作内容了，不可以替换的！");
                }
                
            }
            else
            {
                MessageBox.Show("已经开始的工作内容，不可以替换的！");
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            string tempPath = Application.StartupPath + @"\待办事项\" + @"待办事项.xlsx";
            XSSFWorkbook wk = null;
            using (FileStream fs = File.Open(tempPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                //把xls文件读入workbook变量里，之后就可以关闭了
                wk = new XSSFWorkbook(fs);
                fs.Close();
            }

            ISheet sheet = wk.GetSheetAt(0);
            ISheet sheet2 = wk.GetSheetAt(1);
            int rowcount2 = sheet2.LastRowNum;
            for (int i = 0; i <= rowcount2; i++)
            {
                IRow row = sheet2.GetRow(i);
                if (row != null)
                {
                    dataGridView1.Rows.Add(row.GetCell(0));
                }

            }
            int rowcount = sheet.LastRowNum;
            for (int i = 0; i <= rowcount; i++)
            {
                IRow row = sheet.GetRow(i);
                if (row!=null)
                {
                    dataGridView1.Rows.Add(row.GetCell(0));
                }
                
            }

            using (FileStream fileStream = File.Open(tempPath, FileMode.Create, FileAccess.ReadWrite))
            {
                wk.Write(fileStream);
                fileStream.Close();
            }

            string settingPath = Application.StartupPath + @"\设置\" + @"设置.xlsx";
            XSSFWorkbook wk_setting = null;
            using (FileStream fs = File.Open(settingPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                //把xls文件读入workbook变量里，之后就可以关闭了
                wk_setting = new XSSFWorkbook(fs);
                fs.Close();
            }
            ISheet sheet_setting = wk_setting.GetSheetAt(0);
            for (int i = 1; i < sheet_setting.LastRowNum; i++)
            {
                IRow row = sheet_setting.GetRow(i);
                if (row != null)
                {
                    if (row.GetCell(0) != null&& !row.GetCell(0).ToString().Equals(string.Empty))
                    {
                        comboBox_zoyenwxkda.Items.Add(row.GetCell(0).ToString());
                    }
                    if (row.GetCell(1) != null && !row.GetCell(1).ToString().Equals(string.Empty))
                    {
                        comboBox_zoyenwxkxn.Items.Add(row.GetCell(1).ToString());
                    }
                    if (row.GetCell(2) != null && !row.GetCell(2).ToString().Equals(string.Empty))
                    {
                        comboBox_kehuue.Items.Add(row.GetCell(2).ToString());
                    }
                    if (row.GetCell(3) != null && !row.GetCell(3).ToString().Equals(string.Empty))
                    {
                        comboBox_xits.Items.Add(row.GetCell(3).ToString());
                    }
                    if (row.GetCell(4) != null && !row.GetCell(4).ToString().Equals(string.Empty))
                    {
                        textBox2.Text = row.GetCell(4).ToString();
                    }
                    if (row.GetCell(5) != null && !row.GetCell(5).ToString().Equals(string.Empty))
                    {
                        textBox3.Text = row.GetCell(5).ToString();
                    }
                }

            }

            using (FileStream fileStream = File.Open(settingPath, FileMode.Create, FileAccess.ReadWrite))
            {
                wk_setting.Write(fileStream);
                fileStream.Close();
            }

            label12.Text = DateTime.Now.ToString("hh:mm:dd") + "  全部加载成功！";


        }

        private void button_save_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("explorer.exe", @"D:\工作日志");
        }

        private void Button1_Click_1(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("explorer.exe",Application.StartupPath+ @"\待办事项");
        }

        private void DataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            string tempPath = Application.StartupPath + @"\待办事项\" + @"待办事项.xlsx";
            XSSFWorkbook wk = null;
            using (FileStream fs = File.Open(tempPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                //把xls文件读入workbook变量里，之后就可以关闭了
                wk = new XSSFWorkbook(fs);
                fs.Close();
            }
            ISheet sheet = wk.GetSheetAt(0);
            int rowcount = sheet.LastRowNum;
            for (int i = 1; i <= rowcount; i++)
            {
                sheet.ShiftRows(i, i+1, -1);
            }
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                if (dataGridView1.Rows[i].Cells[0].Value != null && !(dataGridView1.Rows[i].Cells[0].Value.ToString().Equals("")))
                {
                    IRow row = sheet.CreateRow(i);
                    row.CreateCell(0).SetCellValue(dataGridView1.Rows[i].Cells[0].Value.ToString());
                }
            }
            using (FileStream fileStream = File.Open(tempPath, FileMode.Create, FileAccess.ReadWrite))
            {
                wk.Write(fileStream);
                fileStream.Close();
            }
            label12.Text = DateTime.Now.ToString("hh:mm:dd") + "  待办事项同步成功！";
        }

        
    }
}


